on_install() {
  # 延迟20秒再执行，避免开机冲突
  (
    sleep 20

    # ==================== 小核 A520 (cpu0-1) ====================
    echo 364800 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
    echo 364800 > /sys/devices/system/cpu/cpu1/cpufreq/scaling_min_freq
    echo 1132800 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
    echo 1132800 > /sys/devices/system/cpu/cpu1/cpufreq/scaling_max_freq

    # ==================== 中核 A720 (cpu2-6) ====================
    for cpu in 2 3 4 5 6; do
      echo 499200 > /sys/devices/system/cpu/cpu$cpu/cpufreq/scaling_min_freq
      echo 2515200 > /sys/devices/system/cpu/cpu$cpu/cpufreq/scaling_max_freq
    done

    # ==================== 大核 X4 (cpu7) ====================
    echo 480000 > /sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq
    echo 2169600 > /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq

  ) &
}

set_perm_recursive $MODPATH 0 0 0755 0644
