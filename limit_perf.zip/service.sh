#!/system/bin/sh
sleep 10

# 辅助写入函数
write(){ [ -f "$1" ] && echo "$2" > "$1" 2>/dev/null; }

# ==================== 小核 (cpu0-1) ====================
for c in 0 1; do
    p=/sys/devices/system/cpu/cpu$c
    write $p/cpufreq/scaling_min_freq 364800
    write $p/cpufreq/scaling_max_freq 1132800
done

# ==================== 中核 (cpu2-6) ====================
for c in 2 3 4 5 6; do
    p=/sys/devices/system/cpu/cpu$c
    write $p/cpufreq/scaling_min_freq 499200
    write $p/cpufreq/scaling_max_freq 2515200
done

# ==================== 大核 (cpu7) ====================
p7=/sys/devices/system/cpu/cpu7
write $p7/cpufreq/scaling_min_freq 480000
write $p7/cpufreq/scaling_max_freq 2169600